sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("slpnamespace.slpapp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);